% Bendlet Toolbox, 1.0
%
% Copyright (c) 2016, Philipp Petersen and Christian Lessig.
%
% Usage (from the directory where BLcontents.m is located):
%
% To run the example scripts:
% >> addpath Examples/
% >> BLExampleAnalysis
% >> BLExampleAnalyseCurvature
%
%
% To run the experiment that generates Fig. 2 in [1]:
% >> addpath Experiments/
% >> BLAnalyseCurvatureCircle
% >> BLVisualizeAnalyseCurvatureCircle
%
%
% Contents:
%
% Note: Functions belonging to the bendlet toolbox have a prefix 'BL', e.g.
%       BLgetBendletSystem2D() (in contrast to functions in the ShearLab
%       toolbox where the prefix 'SL' is used)
%
% 2D: Functionality to construct different 2D bendlet systems
%
% Data: This folder contains the images and videos used in the sample
%       scripts.
%
% Examples: This folder contains several sample scripts that should give
%           you a good understanding of how to use the Bendlet toolbox. A
%           good starting point is BLExampleAnalysis
%
% Experients: Contains the scripts to reproduce the figures in [1].
%
% Util: This folder contains utility functionality not directly related to
%       bendlets.
%
% For more details on Bendlets:
%
% [1] C. Lessig, P. Petersen, M. Sch�fer, Bendlets: A Higher-Order Shearlet
%     Transform with Bent Elements.
%
% Copyright notice:
%
% V1: The bendlet toolbox was written by
%     Philipp Petersen (philipp.petersen@tu-berlin.de)
%     Christian Lessig (lessig@dgp.toronto.edu)
%     based on the Shearlab toolbox (www.shearlab.org).
%
%
%  This file is part of BendLab: A Bendlet Toolbox.
%
%  BendLab is free software: you can redistribute it and/or modify
%  it under the terms of the GNU General Public License as published by
%  the Free Software Foundation, either version 3 of the License, or
%  (at your option) any later version.
%
%  BendLab is distributed in the hope that it will be useful,
%  but WITHOUT ANY WARRANTY; without even the implied warranty of
%  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%  GNU General Public License for more details.
%
%  You should have received a copy of the GNU General Public License
%  along with BendLab.  If not, see <http://www.gnu.org/licenses/>.
