% %% Compute decay rates as a function of bending for circles with 
% % different radi.

addpath( './2D', './Util');

% parameters used for experiment in Lessig et al. (requires 64 GB of RAM)
res = 4096 * 8;
num_scales = 10;

alpha = 0.335;
mn_bends = 5;
num_shears = zeros( 1, num_scales);
num_bends = mn_bends * ones( 1, num_scales);

% apron for window
apron_pix = 20;

% radi are specified assuming the domain is the square [-1,1] x [-1,1]
radi = [0.1, 0.15, 0.2, 0.25, 0.3, 0.35, 0.4, 0.45];

%% generate bendlet system

tic;
sys = BLgetBendletSystem2DSparseConv( res, res, num_scales, ...
                                      num_shears, num_bends, alpha, ...
                                      100*eps, [1]);
tsys = toc;

%% Precomputations for signal

tic;

% coordinates in x direction
coords_x = zeros( res, res);
for( i = 1 : (res/2))
    coords_x(:,i + (res/2)) = i;
end
coords_x( : , 1:(res/2) ) = -coords_x( : , end:-1:res/2+1 );

% coordinates in y direction
coords_y = coords_x';
coords_y = coords_y(end:-1:1,:);

% squared distance
dist_2 = coords_x .* coords_x + coords_y .* coords_y; 

tprecompsig = toc;

%% Run for all radi

tic;

ens = zeros( numel(radi), sys.nBendlets);
ens_bend = zeros( numel(radi), 2*mn_bends+1, num_scales);

ridx = 1;
for r = radi

  % Construct test signal

  % squared radius
  r_pix_2 = (r * (res/2))^2 + 1;
  % find all elements belonging to the circle
  idxs = find( dist_2 <= r_pix_2);
  
  % create circle signal
  sig = zeros( res, res);
  sig(idxs) = 1;
  
  % Compute bendlet transform
  
  % define window: region around jump discontinuity of circle on x-axis
  % for positive x
  win_r = [ 0, 0];
  win_c = [ floor((res/2 * radi(ridx))-apron_pix), ...
            ceil((res/2 * radi(ridx))+apron_pix)];
  
  % compute transform
  coeffs = BLbenddec2DSparseConvWindow( sig, sys, win_r, win_c);
    

  % Analyse: extract decay rates as a function of bending parameter

  % Extract magnitude of coefficients for each bending and level
  for( i = 1 : sys.nBendlets)
      ens(ridx,i) = max( abs(coeffs{i}));
  end

  % Sort after bendings
  for( i = 1 : sys.nBendlets)

      params = sys.bendletIdxs(i,:);
      % skip scaling function level
      if( params(2) < 1)
         continue; 
      end
      % just consider first cone
      if( params(1) > 1)
         continue;
      end

      ens_bend( ridx, params(4)+mn_bends+1, params(2)) = ens(ridx,i);

  end

    ridx = ridx + 1;

end

texperiment = toc;

% save data 
save( 'BLAnalyseCurvatureCircle_Results.mat', 'radi', 'ens', 'ens_bend');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  Copyright (c) 2016, Philipp Petersen and Christian Lessig.
%
%  If you use or mention this code in a publication please cite 
%  C. Lessig, P. Petersen, M. Sch?fer, Bendlets: A Second Order Shearlet
%    Transform with Bent Elements.
% 
%  This file is part of BendLab: A Bendlet Toolbox.
% 
%  BendLab is free software: you can redistribute it and/or modify
%  it under the terms of the GNU General Public License as published by
%  the Free Software Foundation, either version 3 of the License, or
%  (at your option) any later version.
% 
%  BendLab is distributed in the hope that it will be useful,
%  but WITHOUT ANY WARRANTY; without even the implied warranty of
%  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%  GNU General Public License for more details.
% 
%  You should have received a copy of the GNU General Public License
%  along with BendLab.  If not, see <http://www.gnu.org/licenses/>.

  