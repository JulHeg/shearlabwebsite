%% Visualize experimental results generated with BLAnalyseCurvatureCircle

% fix color scheme
cc=hsv( size( ens_bend, 2));

% separate plot for each radius
ridx = 1;
for r = radi
  
  leg_str = {};
  figure; 
  hold on;
  
  % iterate over all bendings
  bend = -mn_bends;
  for i = 1:size( ens_bend, 2)
      % skip the finest scale: resolution issues
      semilogy( squeeze(ens_bend(ridx,i,1:end-1))', 'color', cc(i,:));
      leg_str{end+1} = num2str( bend);
      bend = bend + 1;
  end
  
  % beautification
  set(gca,'yscale','log');
  legend( leg_str);
  title( ['r = ', num2str(radi(ridx))]);

  ridx = ridx + 1;
  
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  Copyright (c) 2016, Philipp Petersen and Christian Lessig.
%
%  If you use or mention this code in a publication please cite 
%  C. Lessig, P. Petersen, M. Sch?fer, Bendlets: A Second Order Shearlet
%    Transform with Bent Elements.
% 
%  This file is part of BendLab: A Bendlet Toolbox.
% 
%  BendLab is free software: you can redistribute it and/or modify
%  it under the terms of the GNU General Public License as published by
%  the Free Software Foundation, either version 3 of the License, or
%  (at your option) any later version.
% 
%  BendLab is distributed in the hope that it will be useful,
%  but WITHOUT ANY WARRANTY; without even the implied warranty of
%  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%  GNU General Public License for more details.
% 
%  You should have received a copy of the GNU General Public License
%  along with BendLab.  If not, see <http://www.gnu.org/licenses/>.

