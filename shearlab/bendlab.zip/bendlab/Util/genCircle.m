function sig = genCircle( res, r)
%
% sig = genCircle( res, r)
%
% Generate signal with white circle on black background

  % coordinates in x direction
  coords_x = zeros( res, res);
  for( i = 1 : (res/2))
      coords_x(:,i + (res/2)) = i;
  end
  coords_x( : , 1:(res/2) ) = -coords_x( : , end:-1:res/2+1 );

  % coordinates in y direction
  coords_y = coords_x';
  coords_y = coords_y(end:-1:1,:);

  % squared distance
  dist_2 = coords_x .* coords_x + coords_y .* coords_y; 

  % squared radius
  r_pix_2 = (r * (res/2))^2 + 1;
  % find all elements belonging to the circle
  idxs1 = find( dist_2 <= (r_pix_2 * 1.01));
  idxs2 = find( dist_2 >= (r_pix_2 * 0.99));
  idxs = intersect( idxs1, idxs2);
  
  % create circle signal
  sig = zeros( res, res);
  sig(idxs) = 1;
  
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  Copyright (c) 2016, Philipp Petersen and Christian Lessig.
%
%  If you use or mention this code in a publication please cite 
%  C. Lessig, P. Petersen, M. Sch�fer, Bendlets: A Second Order Shearlet
%    Transform with Bent Elements.
% 
%  This file is part of BendLab: A Bendlet Toolbox.
% 
%  BendLab is free software: you can redistribute it and/or modify
%  it under the terms of the GNU General Public License as published by
%  the Free Software Foundation, either version 3 of the License, or
%  (at your option) any later version.
% 
%  BendLab is distributed in the hope that it will be useful,
%  but WITHOUT ANY WARRANTY; without even the implied warranty of
%  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%  GNU General Public License for more details.
% 
%  You should have received a copy of the GNU General Public License
%  along with BendLab.  If not, see <http://www.gnu.org/licenses/>.
