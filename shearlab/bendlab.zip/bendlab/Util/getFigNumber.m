function num = getFigNumber( figHandle)
%
% num = getFigNumber( figHandle)
%
% Get the number associated with a figure.
%
% Input: 
%  figHandle : handle of figure
%
% Output:
%        num : number associated with figure
%
% Remark: wrapper for compatibility with different Matlab versions.

  num = 0;
  if( isnumeric( figHandle))
    num = figHandle;
  else
    num = figHandle.Number;
  end

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  Copyright (c) 2016, Philipp Petersen and Christian Lessig.
%
%  If you use or mention this code in a publication please cite 
%  C. Lessig, P. Petersen, M. Sch�fer, Bendlets: A Second Order Shearlet
%    Transform with Bent Elements.
% 
%  This file is part of BendLab: A Bendlet Toolbox.
% 
%  BendLab is free software: you can redistribute it and/or modify
%  it under the terms of the GNU General Public License as published by
%  the Free Software Foundation, either version 3 of the License, or
%  (at your option) any later version.
% 
%  BendLab is distributed in the hope that it will be useful,
%  but WITHOUT ANY WARRANTY; without even the implied warranty of
%  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%  GNU General Public License for more details.
% 
%  You should have received a copy of the GNU General Public License
%  along with BendLab.  If not, see <http://www.gnu.org/licenses/>.
