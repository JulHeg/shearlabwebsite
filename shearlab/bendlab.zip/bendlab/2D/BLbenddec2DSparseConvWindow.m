function coeffs = BLbenddec2DSparseConvWindow( X, bendletSystem, ...
                                               winRows, winCols, ...
                                               bendletsIdxs )
%
% BLbenddec2DSparseConvWindow: Bendlet decomposition of 2D data using 
%                              spatial convolution for all coefficients in
%                              window specified by winRows and winCols
%                              and for the bendlets specified by 
%                              bendletsIdxs
%
% Input:
%
%              X: 2D data in spatial domain.
%  bendletSystem: Sparse bendlet system in spatial domain 
%                 (generated with BLgetBendletSystem2DSparseConv())
%        winRows: row window for which coefficients are to be computed
%        colRows: colum window for which coefficients are to be computed
%   bendletsIdxs: list of bendlets (by index for bendletSystem) for which
%                 coefficients in window are to be computed
%
% Output:
%
%         coeffs: Bendlet transform coefficients for specified parameters
%
% Example: see BLExampleAnalyseCurvature

    %% check input arguments
    if nargin < 2
        error('Not enough input parameters!');
    end

    assert( all(winRows < size(X,1)/2));
    assert( all(winCols < size(X,2)/2));
        
    defval( 'winRows', [0, 0]);
    defval( 'winCols', [0, 0]);
    defval( 'bendletsIdxs', [1 : bendletSystem.nBendlets]);

    %% Compute coefficients
 
    coeffs = cell( numel(bendletsIdxs), 1);
    
    idx_j = 1;
    for j = bendletsIdxs
    
      psi = rot90( bendletSystem.bendlets{j}, 2);
      psi_supp = bendletSystem.bendletsSupp(j,:);
      
      coeffs{idx_j} = zeros( winRows(2) - winRows(1) + 1, ...
                             winCols(2) - winCols(1) + 1 );
      
      idx_r = 1; 
      for dx = winRows(1) : winRows(2)
        idx_c = 1;
        for dy = winCols(1) : winCols(2)    
    
          idxs = [ psi_supp(1) + dx - 1, ...
                   psi_supp(2) + dx - 1, ...
                   psi_supp(3) + dy - 1, ...
                   psi_supp(4) + dy - 1 ];
      
          Xc = padX( X, idxs);  
      
          coeffs{idx_j}(idx_r,idx_c) = sum( sum( Xc .* psi));
          idx_c = idx_c + 1;
          
        end
        idx_r = idx_r + 1;      
      end
      idx_j = idx_j + 1;
    end
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Xc = padX( X, idxs)
%
% Introduce zero padding in X if necessary and 
% 
  assert( idxs(2) >= idxs(1));
  assert( idxs(4) >= idxs(3));

  % determine if padding is necessary 
  if( all( idxs > 0) &&  (idxs(2) < size(X,1)) && (idxs(4) < size(X,2)))
    Xc = X( idxs(1) : idxs(2) , idxs(3) : idxs(4) );
  else
    
    % zero pad X 
    Xc = X;
    
    % top
    offset = 0;
    if( idxs(1) <= 0)
      Xc = [zeros( abs(idxs(1))+1, size(Xc,2)) ; Xc];
      offset = abs(idxs(1))+1;
    else
      Xc = Xc( idxs(1):end , : );
      offset = -idxs(1) + 1;
    end
    
    % bottom
    if( idxs(2) > size(X,1))
      Xc = [ Xc ; zeros( idxs(2)-size(X,1), size(Xc,2)) ]; 
    else
      Xc = Xc( 1:(offset + idxs(2)), : );
    end
      
    % left
    offset = 0;
    if( idxs(3) <= 0)
      Xc = [zeros( size(Xc,1), abs( idxs(3))+1) , Xc];
      offset = abs( idxs(3))+1;
    else
      Xc = Xc( : , idxs(3):end );
      offset = -idxs(3) + 1;
    end
    
    % right
    if( idxs(4) > size(X,1))
      Xc = [ Xc , zeros( size(Xc,1), idxs(4)-size(X,1)) ]; 
    else
      Xc = Xc( : , 1:(offset + idxs(4)) );
    end

  end

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  Copyright (c) 2016, Philipp Petersen and Christian Lessig.
%
%  If you use or mention this code in a publication please cite 
%  C. Lessig, P. Petersen, M. Sch�fer, Bendlets: A Second Order Shearlet
%    Transform with Bent Elements.
% 
%  This file is part of BendLab: A Bendlet Toolbox.
% 
%  BendLab is free software: you can redistribute it and/or modify
%  it under the terms of the GNU General Public License as published by
%  the Free Software Foundation, either version 3 of the License, or
%  (at your option) any later version.
% 
%  BendLab is distributed in the hope that it will be useful,
%  but WITHOUT ANY WARRANTY; without even the implied warranty of
%  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%  GNU General Public License for more details.
% 
%  You should have received a copy of the GNU General Public License
%  along with BendLab.  If not, see <http://www.gnu.org/licenses/>.
