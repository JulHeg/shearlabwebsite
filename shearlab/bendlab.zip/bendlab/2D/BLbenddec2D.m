function coeffs = BLbenddec2D( X, bendletSystem)
%
% BLbenddec2D: Bendlet decomposition of 2D data.
%
% Input:
%
%              X: 2D data in spatial domain of size N x M.
%  bendletSystem: Bendlet system whose size matches X, i.e. N x M.
%
% Output:
%
% coeffs: N x M x K array containing all bendlet coefficients, that is all
%         inner products with the given data, of all translates of the 
%         bendlet in the specified system. 
%
% Example:
%
% X = double(imread('Data/Snowman.png'));
% bendletSystem =  BLgetBendletSystem2D( size(X,1), size(X,2));
% coeffs = BLbenddec2D( X, bendletSystem);

    % check input arguments
    if nargin < 2
        error('Not enough input parameters!');
    end

    % get data in frequency domain
    Xfreq = fftshift(fft2(X));

    %compute shearlet coefficients at each scale
    %note that pointwise multiplication in the fourier domain equals 
    %convolution in the time-domain
    for j = 1:bendletSystem.nBendlets

        coeff_hat = Xfreq .* conj( bendletSystem.bendlets(:,:,j));
        coeff = ifftshift( ifft2( coeff_hat));
        coeffs(:,:,j) = coeff;

    end
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  Copyright (c) 2016, Philipp Petersen and Christian Lessig.
%
%  If you use or mention this code in a publication please cite 
%  C. Lessig, P. Petersen, M. Sch�fer, Bendlets: A Second Order Shearlet
%    Transform with Bent Elements.
% 
%  This file is part of BendLab: A Bendlet Toolbox.
% 
%  BendLab is free software: you can redistribute it and/or modify
%  it under the terms of the GNU General Public License as published by
%  the Free Software Foundation, either version 3 of the License, or
%  (at your option) any later version.
% 
%  BendLab is distributed in the hope that it will be useful,
%  but WITHOUT ANY WARRANTY; without even the implied warranty of
%  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%  GNU General Public License for more details.
% 
%  You should have received a copy of the GNU General Public License
%  along with BendLab.  If not, see <http://www.gnu.org/licenses/>.


