function [mask] = BendletMask(m,n,System,c, alpha)
%% Shearlet subsampling mask for Gramian
% Input:
%   m,n: x,y-dimension
%   System: shearlet system
%   b: offset
%   c: subsampling parameter
%   s: parameter for weighting matrix
%
% Output:
%   mask: subsampling mask
%   wMat: corresponding weighting matrix

%%
% cut off boundaries
% maskS = ones(m,n, System.nShearlets);
 
 J = max(System.bendletIdxs(:,2));

mask = cell(System.nShearlets);
for k = 1:System.nShearlets
mask{k} = sparse(m,n);
end

% for j = 1:System.nShearlets
%maskS(1:(1+b)*floor(2^0.5*(J-System.bendletIdxs(j,2))),:,j) = 0;
%maskS(end-(1+b)*floor(2^0.5*(J-System.bendletIdxs(j,2))):end,:,j) = 0;
%maskS(:,1:(1+b)*floor(2^0.5*(J-System.bendletIdxs(j,2))),j) = 0;
%maskS(:,end-(1+b)*floor(2^0.5*(J-System.bendletIdxs(j,2))):end,j) = 0;
% end
%%

%floor(2^0.5*0.5*(J-System.bendletIdxs(j,2)))
%%
%do subsamplng for translation set in levels
 for j = 1:System.nShearlets
     if(System.bendletIdxs(j,1) == 1)
         mask{j}( 1:c*ceil(2^(J-System.bendletIdxs(j,2))):end ,1:c*ceil(2^(J-alpha*System.bendletIdxs(j,2))):end) = 1;%maskS(1:c*ceil(2^(J-System.bendletIdxs(j,2))):end ,1:c*ceil(2^(J-alpha*System.bendletIdxs(j,2))):end ,j);
     elseif (System.bendletIdxs(j,1) == 2)
         mask{j}( 1:c*ceil(2^(J-alpha*System.bendletIdxs(j,2))):end ,1:c*ceil(2^(J-System.bendletIdxs(j,2))):end) = 1;% maskS(1:c*ceil(2^(J-alpha*System.bendletIdxs(j,2))):end ,1:c*ceil(2^(J-System.bendletIdxs(j,2))):end ,j);
     else
         mask{j}( 1:c*ceil(2^(J-System.bendletIdxs(j,2))):end ,1:c*ceil(2^(J-System.bendletIdxs(j,2))):end) = 1;%maskS(1:c*ceil(2^(J-System.bendletIdxs(j,2))):end ,1:c*ceil(2^(J-System.bendletIdxs(j,2))):end ,j);
     end

 end
% j = System.nShearlets;
% %wMat(:,:,j) = 2^(System.bendletIdxs(j,2)*s);
% mask( :,:,j) = maskS(:,: ,j);
%%
% delete zero columns and rows
%wMat(~any(wMat,2),:)=[];
%wMat(:,~any(wMat,1))=[];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  Copyright (c) 2016, Philipp Petersen and Christian Lessig.
%
%  If you use or mention this code in a publication please cite 
%  C. Lessig, P. Petersen, M. Sch�fer, Bendlets: A Second Order Shearlet
%    Transform with Bent Elements.
% 
%  This file is part of BendLab: A Bendlet Toolbox.
% 
%  BendLab is free software: you can redistribute it and/or modify
%  it under the terms of the GNU General Public License as published by
%  the Free Software Foundation, either version 3 of the License, or
%  (at your option) any later version.
% 
%  BendLab is distributed in the hope that it will be useful,
%  but WITHOUT ANY WARRANTY; without even the implied warranty of
%  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%  GNU General Public License for more details.
% 
%  You should have received a copy of the GNU General Public License
%  along with BendLab.  If not, see <http://www.gnu.org/licenses/>.
