function bendletsystem = BLgetBendletSystem2DSparse( rows, cols, ...
                                                     nScales, ...
                                                     shears, bendings, ...
                                                     a_scale, sth)
%
% BLgetBendletSystem2DSparse: Computes a 2D bendlet system where a sparse 
%                             representation is employed for the bendlets.
%
% Input:
%
%                  rows: Number of rows.
%                  cols: Number of columns.
%               nScales: Number of scales of the desired bendlet system.
%                        Has to be >= 1.
%                shears: A 1xnScales sized array, specifying the level of
%                        shearing occuring on each scale. Each entry of
%                        shearLevels has to be >= 0. a value shears = [1 2 3 4]
%                        means that on scale 1 there is one shear in each
%                        direction on scale 1, two scales in each
%                        direction on scale 2, etc.
%              bendings: A 1xnScales sized array, specifying the level of
%                        bending occuring on each scale. Each entry of
%                        bendings has to be >= 0. The usage is the same as
%                        with shears.
%               a_scale: Alpha value for the scaling of the bendlet
%                        system.
%                   sth: threshold for clamping non-zero values
%
%  nScales, shears, bendings, a_scale, sth are set automatically if not 
%    specified, i.e. there are default parameters (depending on rows, cols)
%
% Output:
%
%         bendletsystem: A structure containing the specified bendlet system.   
%             .bendlets: A cell array of N sparse 2D bendlets in the spatial 
%                        domain where X and Y denote the size of each shearlet.
%            .nBendlets: Number of bendlets in the bendletsystem.shearlets
%                        array. This number also describes the redundancy 
%                        of the system.
%          .bendletIdxs: A Nx4 array, specifying each shearlet in the system
%                        in the format [cone scale shearing bending] where N
%                        denotes the number of shearlets. The lowpass bendlet is 
%                        indexed by [0 0 0 0].
%     .dualFrameWeights: Weight factor for dual frame functions.


    %% check input arguments
    if nargin < 2
        error('Not enough input parameters!');
    end
    if nargin < 3
      if cols ~= rows
        error('Not enough input parameters!');
      end
    end

    % set default parameters if not given
    defval( 'nScales', round(log(rows)/log(2.0) - 5.0));
    defval( 'shears', genShearsDefault(nScales,[]));
    defval( 'bendings', genBendingsDefault(nScales,[]));
    defval( 'a_scale', 0.335);
    defval( 'sth', 100*eps)
    
    %% construct low frequency window
    lengthPsi = numel( wavefun('db8',nScales));
    
    % make B-spline lowpass filter
    diffPhi = 6;
    lengthPhi = floor( lengthPsi / diffPhi);
    phi = ones(1,floor(lengthPhi));
    for u = 1:diffPhi
       phi = conv(phi, ones(1,floor(lengthPhi)));
    end

    %% construct system
    bendlets = {};
    dualFrameWeights = zeros( rows, cols);
    
    % construct all bendlets
    idx = 1;
    for cone = 1:2
        for scale = 1:nScales
            for shear = -shears(scale):shears(scale)
                for bend = -bendings(scale):bendings(scale)
                    
                    psi = BLbendPsi( lengthPhi, diffPhi, scale, nScales, ...
                                     rows, cols, ...
                                     shear/max((shears(scale)),1), ...
                                     bend/max((bendings(scale)),1), ...
                                     a_scale);
                    if 2 == cone
                        psi = rot90(psi);
                    end
                    
                    psihat = fftshift( fft2( psi));
                    dualFrameWeights = dualFrameWeights + abs(psihat).^2;
                    
                    psi( abs(psi) < sth) = 0.0;
                    bendlets{idx} = sparse( psi);
                    
                    bendletIdxs(idx, 1:4) = [cone, scale, shear, bend];
                    idx = idx+1;
                end
            end
        end
    end
    
    %% add scaling function
    low = phi.'*phi;
    [a1,a2] = size(low);
    % pad in all directions
    low = padarray(low, floor([(rows-a1)/2 (cols-a2)/2]), 0, 'pre');
    low = padarray(low, ceil([(rows-a1)/2 (cols-a2)/2]), 0, 'post');
    low = low/norm(low(:));
    % Fourier transform for dual weights
    phihat = fftshift(fft2(low));
    dualFrameWeights = dualFrameWeights + abs(phihat).^2; 
    % threshold and add to structure
    low( abs(low) < sth) = 0.0;   
    bendlets{idx} = low;
    bendletIdxs(idx, 1:4) = [0, 0, 0, 0];
    
    %% construct system
    bendletsystem = struct;
    bendletsystem.bendlets = bendlets;
    bendletsystem.nBendlets = idx;
    bendletsystem.bendletIdxs = bendletIdxs;
    bendletsystem.dualFrameWeights = dualFrameWeights;

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function shears = genShearsDefault( nScales, shears)

    if( nScales > 0)
        shears = [max(1.0,ceil( log(nScales)/log(2))) shears];
        shears = genShearsDefault( nScales-1, shears);
    end
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function bendings = genBendingsDefault( nScales, bendings)

    if( nScales > 0)
        bendings = [max(1.0,ceil( log(nScales)/log(2))) bendings];
        bendings = genShearsDefault( nScales-1, bendings);
    end
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  Copyright (c) 2016, Philipp Petersen and Christian Lessig.
%
%  If you use or mention this code in a publication please cite 
%  C. Lessig, P. Petersen, M. Sch�fer, Bendlets: A Second Order Shearlet
%    Transform with Bent Elements.
% 
%  This file is part of BendLab: A Bendlet Toolbox.
% 
%  BendLab is free software: you can redistribute it and/or modify
%  it under the terms of the GNU General Public License as published by
%  the Free Software Foundation, either version 3 of the License, or
%  (at your option) any later version.
% 
%  BendLab is distributed in the hope that it will be useful,
%  but WITHOUT ANY WARRANTY; without even the implied warranty of
%  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%  GNU General Public License for more details.
% 
%  You should have received a copy of the GNU General Public License
%  along with BendLab.  If not, see <http://www.gnu.org/licenses/>.

