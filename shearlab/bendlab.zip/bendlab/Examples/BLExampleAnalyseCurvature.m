%% Compute decay rates as a function of bending for circles with 
% different radi.

addpath( './2D', './Util');

% parameters used for experiment in Lessig et al. (requires 64 GB of RAM)
% res = 4096 * 8;
% num_scales = 10;
% reduced parameters suitable for Desktop computers
res = 4096;
num_scales = 7;
alpha = 0.335;
mn_bends = 5;
num_shears = zeros( 1, num_scales);
num_bends = mn_bends * ones( 1, num_scales);

% radi are specified assuming the domain is the square [-1,1] x [-1,1]
radi = [0.1, 0.15, 0.2, 0.25, 0.3, 0.35, 0.4, 0.45];

%% generate bendlet system
sys = BLgetBendletSystem2DSparseConv( res, res, num_scales, ...
                                      num_shears, num_bends, alpha, ...
                                      100*eps, [1]);

%% Construct test signals

% coordinates in x direction
coords_x = zeros( res, res);
for( i = 1 : (res/2))
    coords_x(:,i + (res/2)) = i;
end
coords_x( : , 1:(res/2) ) = -coords_x( : , end:-1:res/2+1 );

% coordinates in y direction
coords_y = coords_x';
coords_y = coords_y(end:-1:1,:);

% squared distance
dist_2 = coords_x .* coords_x + coords_y .* coords_y; 

sigs = { };
for r = radi

    % squared radius
    r_pix_2 = (r * (res/2))^2 + 1;
    % find all elements belonging to the circle
    idxs = find( dist_2 <= r_pix_2);
  
    % create circle signal
    sig = zeros( res, res);
    sig(idxs) = 1;
    sigs{end+1} = sig;
    
end

%% Compute bendlet transform

% apron for window
apron_pix = 20;

% for all radi
coeffs = cell(numel(radi),1);
for i = 1:numel(radi)
  
    % define window: region around jump discontinuity of circle on x-axis
    % for positive x
    win_r = [ 0, 0];
    win_c = [ floor((res/2 * radi(i))-apron_pix), ...
              ceil((res/2 * radi(i))+apron_pix)];
  
    % compute transform
    coeffs{i} = BLbenddec2DSparseConvWindow( sigs{i}, sys, win_r, win_c);
    
    i = i + 1;
end

%% Analyse: extract decay rates as a function of bending parameter

% Extract magnitude of coefficients for each bending and level
ens = zeros( numel(radi), sys.nBendlets);
ridx = 1;
for r = radi

    for( i = 1 : sys.nBendlets)
        ens(ridx,i) = max( abs(coeffs{ridx}{i}));
    end
        
    ridx = ridx + 1;
end

% Sort after bendings
ens_bend = zeros( numel(radi), 2*mn_bends+1, num_scales);
ridx = 1;
for r = radi
    for( i = 1 : sys.nBendlets)
   
        params = sys.bendletIdxs(i,:);
        % skip scaling function level
        if( params(2) < 1)
           continue; 
        end
        % just consider first cone
        if( params(1) > 1)
           continue;
        end

        ens_bend( ridx, params(4)+mn_bends+1, params(2)) = ens(ridx,i);

    end
    
    ridx = ridx + 1;
end

%% Visualize

% fix color scheme
cc=hsv( size( ens_bend, 2));

% separate plot for each radius
ridx = 1;
for r = radi
  
  leg_str = {};
  figure; 
  hold on;
  
  % iterate over all bendings
  bend = -mn_bends;
  for i = 1:size( ens_bend, 2)
      % skip the finest scale: resolution issues
      semilogy( squeeze(ens_bend(ridx,i,1:end-1))', 'color', cc(i,:));
      leg_str{end+1} = num2str( bend);
      bend = bend + 1;
  end
  
  % beautification
  set(gca,'yscale','log');
  legend( leg_str);
  title( ['r = ', num2str(radi(ridx))]);

  ridx = ridx + 1;
  
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  Copyright (c) 2016, Philipp Petersen and Christian Lessig.
%
%  If you use or mention this code in a publication please cite 
%  C. Lessig, P. Petersen, M. Sch�fer, Bendlets: A Second Order Shearlet
%    Transform with Bent Elements.
% 
%  This file is part of BendLab: A Bendlet Toolbox.
% 
%  BendLab is free software: you can redistribute it and/or modify
%  it under the terms of the GNU General Public License as published by
%  the Free Software Foundation, either version 3 of the License, or
%  (at your option) any later version.
% 
%  BendLab is distributed in the hope that it will be useful,
%  but WITHOUT ANY WARRANTY; without even the implied warranty of
%  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%  GNU General Public License for more details.
% 
%  You should have received a copy of the GNU General Public License
%  along with BendLab.  If not, see <http://www.gnu.org/licenses/>.

  