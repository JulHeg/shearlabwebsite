% Computes a bendlet system, shows some bent elements, and some
% coefficients for a snowman sketch

addpath( './2D', './Util');

% parameters of bendlet system
res = 512;
num_scales = 4;
alpha = 0.335;
num_shears = [1 1 2 2];
num_bends = [1 1 1 2];

%% Construction

% Construct bendlet system
disp( 'Starting construction of bendlet system.');
tic;
sys = BLgetBendletSystem2D( res, res, num_scales, ...
                            num_shears, num_bends, alpha);
t = toc;
disp(['Finished construction of bendlet system (', num2str(t), ' sec.).']);


%% Show some elements first in time then in frequency:
fig1 = figure;
disp(['Fig. ', num2str(getFigNumber(fig1)), ': ', ...
      'Bendlet elements in spatial domain (', ...
      'the title indicates [cone scale shear bending]).']);
for k = 1:16
  subplot(4,4,k); 
  imagesc( abs( ifft2( ifftshift(sys.bendlets(:,:,k)))));
  a = sys.bendletIdxs(k,:);
  title( strcat(num2str(a(1)), ',', num2str(a(2)),',', ...
                num2str(a(3)),',', num2str(a(4)) ));
end
pause(0.1);

fig2 = figure;
disp(['Fig. ', num2str(getFigNumber(fig2)), ': ', ...
      'Bendlet elements in frequency domain(', ...
      'the title indicates [cone scale shear bending]).']);
for k = 1:16
  subplot(4,4,k); 
  imagesc( abs( sys.bendlets(:,:,k)));
  a = sys.bendletIdxs(k,:);
  title( strcat(num2str(a(1)), ',', num2str(a(2)),',', ...
                num2str(a(3)),',', num2str(a(4)) ));
end
pause(0.1);

%% Analysis

% load signal
load('./Data/snow.mat')
img = snow;

% perform analysis
tic;
coeffs = BLbenddec2D( img, sys);
tdelta = toc;
disp( sprintf( 'Computation of transform took %.2f sec.', tdelta));

%% Show some coefficients

plotmax = max(max(max(abs(coeffs(:,:,1:end-1)))));
plotmin = min(min(min(abs(coeffs(:,:,1:end-1)))));

fig3 = figure;
disp(['Fig. ', num2str(getFigNumber(fig3)), ': ', ...
      'Some bendlet coefficients of a snowman sketch (', ...
      'the title indicates [cone scale shear bending]).']);
for k = 1:16
  subplot(4,4,k); 
  imagesc( abs( coeffs(:,:,k)));
  caxis([plotmin plotmax]);
  a = sys.bendletIdxs(k,:);
  title( strcat(num2str(a(1)), ',', num2str(a(2)),',', ...
                 num2str(a(3)),',', num2str(a(4)) ));
end
pause(0.1);


plotmax = max(max(max(abs(coeffs(:,:,17:end-1)))));
plotmin = min(min(min(abs(coeffs(:,:,17:end-1)))));

% show some more coeffs
fig4 = figure;
disp(['Fig. ', num2str(getFigNumber(fig4)), ': ', ...
      'Some more bendlet coefficients of a snowman sketch (', ...
      'the title indicates [cone scale shear bending]).']);
for k = 1:16
  subplot(4,4,k); 
  imagesc( abs( coeffs(:,:,16+k)));
  caxis([plotmin plotmax]);
  a = sys.bendletIdxs(16+k,:);
  title( strcat(num2str(a(1)), ',', num2str(a(2)),',', ...
                num2str(a(3)),',', num2str(a(4)) ));
end
pause(0.1);


%% Reconstruction

coeffs1 = coeffs;

% Set curved components to zero
for k = 1:sys.nBendlets
if(sys.bendletIdxs(k,4)~=0)
    coeffs1(:,:,k) = zeros(512,512);
end
end

plotmax = max(max(img));
plotmin = min(min(img));

fig5 = figure;
disp(['Fig. ', num2str(getFigNumber(fig5)), ': ', ...
      'Reconstruction with curved components.'])
subplot(1,2,1);
imagesc(img);
colormap(gray);
caxis([plotmin plotmax]); 
subplot(1,2,2);
imagesc(BLbendrec2D(coeffs, sys));
caxis([plotmin plotmax]);


fig6 = figure;
disp(['Fig. ', num2str(getFigNumber(fig6)), ': ', ...
      'Reconstruction with curved components set to zero.'])
subplot(1,2,1);
imagesc(img);
colormap(gray);
caxis([plotmin plotmax]); 
subplot(1,2,2);
imagesc(BLbendrec2D(coeffs1, sys));
caxis([plotmin plotmax]);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  Copyright (c) 2016, Philipp Petersen and Christian Lessig.
%
%  If you use or mention this code in a publication please cite 
%  C. Lessig, P. Petersen, M. Sch�fer, Bendlets: A Second Order Shearlet
%    Transform with Bent Elements.
% 
%  This file is part of BendLab: A Bendlet Toolbox.
% 
%  BendLab is free software: you can redistribute it and/or modify
%  it under the terms of the GNU General Public License as published by
%  the Free Software Foundation, either version 3 of the License, or
%  (at your option) any later version.
% 
%  BendLab is distributed in the hope that it will be useful,
%  but WITHOUT ANY WARRANTY; without even the implied warranty of
%  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%  GNU General Public License for more details.
% 
%  You should have received a copy of the GNU General Public License
%  along with BendLab.  If not, see <http://www.gnu.org/licenses/>.
