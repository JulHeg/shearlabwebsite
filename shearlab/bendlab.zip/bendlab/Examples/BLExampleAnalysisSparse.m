% Computes a bendlet system, shows some bent elements, and some
% coefficients for a house sketch

addpath( './2D', './Util');

% parameters of bendlet system
res = 1024;
num_scales = 5;
alpha = 0.335;
num_shears = [1 1 2 2 2];
num_bends = [1 1 1 2 2];

%% Construct bendlet system

disp( 'Starting construction of bendlet system.');
tic;
sysSparse = BLgetBendletSystem2DSparse( res, res, num_scales, ...
                                        num_shears, num_bends, alpha);
t = toc;
disp(['Finished construction of bendlet system (', num2str(t), ' sec.).']);                                    
                                     
%% Show some elements

fig1 = figure;
disp(['Fig. ', num2str(getFigNumber(fig1)), ': ', ...
      'Bendlet elements in spatial domain (', ...
      'the title indicates [cone scale shear bending]).']);
for k = 1:16
  psi = abs(sysSparse.bendlets{k});
  subplot(4,4,k); 
  imagesc(psi);
  a = sysSparse.bendletIdxs(k,:);
  title( strcat(num2str(a(1)), ',', num2str(a(2)),',', ...
                num2str(a(3)),',', num2str(a(4)) ));
end
pause(0.1);

fig2 = figure;
disp(['Fig. ', num2str(getFigNumber(fig2)), ': ', ...
      'Bendlet elements in frequency domain(', ...
      'the title indicates [cone scale shear bending]).']);
for k = 1:16    
  psihat = abs(fftshift(fft2(full(sysSparse.bendlets{k}))));
  subplot(4,4,k); 
  imagesc(psihat);
  a = sysSparse.bendletIdxs(k,:);
  title( strcat(num2str(a(1)), ',', num2str(a(2)),',', ...
                num2str(a(3)),',', num2str(a(4)) ));
end
pause(0.1);


%% Analysis

X = double(imread('Data/house.png'));
tic;
coeffs = BLbenddec2DSparse( X, sysSparse);
tdelta = toc;
disp( sprintf( 'Computation of transform took %.2f sec.', tdelta));

%% Show some coefficients

plotmax = -inf;
plotmin = inf;
for k = 1:(sysSparse.nBendlets-1)
  plotmax = full(max( plotmax, max(abs(coeffs{k}(:)))));
  plotmin = full(min( plotmin, min(abs(coeffs{k}(:)))));
end

fig3 = figure;
disp(['Fig. ', num2str(getFigNumber(fig3)), ': ', ...
      'Some bendlet coefficients of a snowman sketch (', ...
      'the title indicates [cone scale shear bending]).']);
for k = 1:16
  subplot(4,4,k); 
  imagesc( abs( coeffs{k}));
  caxis([plotmin plotmax]);
  a = sysSparse.bendletIdxs(k,:);
  title( strcat(num2str(a(1)), ',', num2str(a(2)),',', ...
                num2str(a(3)),',', num2str(a(4)) ));
end
pause(0.1);

% show some more coeffs

plotmax = -inf;
plotmin = inf;
for k = 17:(sysSparse.nBendlets-1)
  plotmax = full(max( plotmax, max(abs(coeffs{k}(:)))));
  plotmin = full(min( plotmin, min(abs(coeffs{k}(:)))));
end

% show some more coeffs
fig4 = figure;
disp(['Fig. ', num2str(getFigNumber(fig4)), ': ', ...
      'Some more bendlet coefficients of a snowman sketch (', ...
      'the title indicates [cone scale shear bending]).']);
for k = 1:16    
  subplot(4,4,k); 
  imagesc( abs( coeffs{16+k}));
  caxis([plotmin plotmax]);
  a = sysSparse.bendletIdxs(16+k,:);
  title( strcat(num2str(a(1)), ',', num2str(a(2)),',', ...
                num2str(a(3)),',', num2str(a(4)) ));
end
pause(0.1);

%% Reconstruction

coeffs1 = coeffs;

for k = 1:sysSparse.nBendlets
  if(sysSparse.bendletIdxs(k,4)~=0)
      coeffs1{k} = zeros(size(coeffs1{k},1),size(coeffs1{k},2));
  end
end

% plot reconstruction without curved coefficients
plotmax = max(max(X));
plotmin = min(min(X));

fig5 = figure;
disp(['Fig. ', num2str(getFigNumber(fig5)), ': ', ...
      'Reconstruction with curved components set to zero.'])

subplot(1,2,1);
imagesc(X);
colormap(gray);
caxis([plotmin plotmax]); 

subplot(1,2,2); 
imagesc( BLbendrec2DSparse( coeffs1, sysSparse));
colormap(gray);
caxis([plotmin plotmax]);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  Copyright (c) 2016, Philipp Petersen and Christian Lessig.
%
%  If you use or mention this code in a publication please cite 
%  C. Lessig, P. Petersen, M. Sch�fer, Bendlets: A Second Order Shearlet
%    Transform with Bent Elements.
% 
%  This file is part of BendLab: A Bendlet Toolbox.
% 
%  BendLab is free software: you can redistribute it and/or modify
%  it under the terms of the GNU General Public License as published by
%  the Free Software Foundation, either version 3 of the License, or
%  (at your option) any later version.
% 
%  BendLab is distributed in the hope that it will be useful,
%  but WITHOUT ANY WARRANTY; without even the implied warranty of
%  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%  GNU General Public License for more details.
% 
%  You should have received a copy of the GNU General Public License
%  along with BendLab.  If not, see <http://www.gnu.org/licenses/>.
