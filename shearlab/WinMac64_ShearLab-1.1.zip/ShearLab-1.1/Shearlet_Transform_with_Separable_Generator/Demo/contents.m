% Contents 
%
% 1) dst_denodemo : demo routine for image denoising. 
% 2) dst_nlademo : demo routine for image approximations. 
% 3) demo_shear_coeff : display shearlet coefficients across scales (5 levels).