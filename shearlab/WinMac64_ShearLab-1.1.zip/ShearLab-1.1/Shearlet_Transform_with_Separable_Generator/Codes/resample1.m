% This routine is copied from Contourlet Toolbox. 


function y = resample1(x, type, shift, extmod)

y = resample1(x, type, shift, extmod);

% Resampling according to shear matrix [1 s ; 0 1] 
% See source code resample1.c



