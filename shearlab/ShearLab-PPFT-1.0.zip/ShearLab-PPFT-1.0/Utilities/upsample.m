function y = upsample(x,N,varargin)
y = updownsample(x,N,'Up',varargin{:}); 