%  ShearLab-PPFT-1.0 Toolbox Copying Permissions
%
%  This program is free software: you can redistribute it and/or modify
%  it under the terms of the GNU General Public License as published by
%  the Free Software Foundation, either version 3 of the License, or
%  (at your option) any later version.
%
%  This program is distributed in the hope that it will be useful,
%  but WITHOUT ANY WARRANTY; without even the implied warranty of
%  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%  GNU General Public License for more details.
%
%
%  This software was developed with the support of:
%   + DFG Grant SPP-1324, KU 1446/13-1, and KU 1446/14.
%
%  This package were written by 
%	Xiaosheng Zhuang, Institute of Mathematics, University of Osnabrueck
%   Morteza Shahram, Standford University
%
%  Contributors to this effort include
%   Gitta Kutyniok, Institute of Mathematics, University of Osnabrueck 
%   Jakob Lemvig, Institute of Mathematics, University of Osnabrueck  
%   Wang-Q Lim, Institute of Mathematics, University of Osnabrueck  
%   Davdid L Donoho, Standford Unviersity
%   Morteza Shahram, Standford Unviersity
%
%  Copyright(C)2011, Xiaosheng Zhuang, University of Osnabrueck.
% 
%                         All Rights Reserved
%
%  Send any comments/bugs/errors to xzhuang@uos.de