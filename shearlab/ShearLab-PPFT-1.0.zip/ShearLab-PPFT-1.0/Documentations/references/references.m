%% Refereces
% related papers
%% PDFs 
% * <ShearLab_SampTA_2011.pdf ShearLab_SampTA 2011>
% * <ShearLab_SPIE_2009.pdf ShearLab_SPIE 2009>

%% Website
% * <http://www.shearlab.org/index_publications.html Shearlet Publications>
% * <http://www.shearlet.org   Shearlet.org>