%% SHEARLETTRANSFORM
%
%% Files
% * <ShearletTransform/AdjShearletTransform_help.html AdjShearletTransform> - AdjShearletTransform Adjoint of Shearlet Transform. (W sqrt(w) P)^\star
% * <ShearletTransform/InvShearletTransform_help.html InvShearletTransform> - InvShearletTransform inverse of Shearlet Transform.
% * <ShearletTransform/ShearletTransform_help.html ShearletTransform>    - Digital Shearlet Transform (W sqrt(w) P)X
