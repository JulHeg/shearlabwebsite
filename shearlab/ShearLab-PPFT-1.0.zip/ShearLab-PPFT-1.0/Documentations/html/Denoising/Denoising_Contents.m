%% DENOISING
%
%% Files
% * <Denoising/DenoiseDemo_help.html  DenoiseDemo>  - denoising demo using shearlets
% * <Denoising/dshden_help.html dshden>       - shearlet denosing
% * <Denoising/ShXThres_help.html  ShXThres>     - thresholding shearlet coefficients
% * <Denoising/ShXSort_help.html  ShXSort>     - thresholding shearlet coefficients