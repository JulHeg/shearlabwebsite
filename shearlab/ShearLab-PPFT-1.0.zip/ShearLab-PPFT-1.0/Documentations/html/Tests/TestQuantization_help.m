%% TestQuantization 
% Quantization Test.
%
%% See also
% <TestAlgExact_help.html  TestAlgExact>,
% <TestGeomExact_help.html  TestGeomExact>,
% <TestIsometry_help.html TestIsometry>,
% <TestPackage_help.html TestPackage>,
% <TestRobustness_help.html TestRobustness>,
% <TestShearInvariance_help.html  TestShearInvariance>,
% <TestSpeed_help.html TestSpeed>,
% <TestThresholding_help.html TestThresholding>,
% <TestTightness_help.html TestTightness>,
% <TestTimeFreqLoc_help.html TestTimeFreqLoc>
%
%% Copyright
%   Copyright (C) 2011. Xiaosheng Zhuang, University of Osnabrueck
