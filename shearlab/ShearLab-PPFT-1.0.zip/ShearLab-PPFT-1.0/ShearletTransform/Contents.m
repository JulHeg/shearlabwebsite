% SHEARLETTRANSFORM
%
% Files
%   AdjShearletTransform - AdjShearletTransform Adjoint of Shearlet Transform. (W sqrt(w) P)^\star
%   InvShearletTransform - INVShearletTransform Adjoint of Shearlet Transform.
%   ShearletTransform    - Digital Shearlet Transform (W sqrt(w) P)X
