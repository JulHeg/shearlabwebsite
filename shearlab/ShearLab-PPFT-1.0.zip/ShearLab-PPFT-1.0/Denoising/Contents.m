% DENOISING
%
% Files
%   DenoiseDemo  - denoising demo using shearlets
%   dshden       - shearlet denosing
%   ShXThres     - thresholding shearlet coefficients
