% Contents 
%
% 1) deno_Barbara : image denoising demo script for 'Barbara' image.  
% 2) dsno_Boat : image denoising demo script for 'Boat' image.  
% 3) deno_Goldhill : image denoising demo script for 'Goldhill' image.
% 4) deno_Lena : image denoising demo script for 'Lena' image.    
% 5) deno_Seismic : image denoising demo script for Seismic image.  
%
%
% 6) NLA_Barbara : image approximation demo script for 'Barbara' image.  
% 7) NLA_Boat : image approximation demo script for 'Boat' image.  
% 8) NLA_Goldhill : image approximation demo script for 'Goldhill' image.
% 9) NLA_Lena : image approximation demo script for 'Lena' image.    
% 10) NLA_Seismic : image approximation demo script for Seismic image.  
