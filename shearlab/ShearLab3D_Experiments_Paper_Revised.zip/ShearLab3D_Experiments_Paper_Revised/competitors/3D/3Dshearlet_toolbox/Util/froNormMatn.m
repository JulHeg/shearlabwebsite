function val= froNormMatn(x,y)

val =sqrt(sum( (x(:)-y(:)).^2));