%% setup

nExperiment = 1;
iterations = 50;
stopFactor = 1.0e-02;
sizeX = 192;
sizeY = 192;
sizeZ = 192;

masks = {'data_inpainting_3d/mask_rand','data_inpainting_3d/mask_cubes'};
videos = {'data_denoising_3d/mobile2_sequence.mat','data_denoising_3d/coastguard_sequence.mat'};


testSL3D1 = 0;
testSL3D2 = 0;
testSURF = 0;
testSL2D2 = 0;
testFCT3D = 0;

savePSNR = 1;
saveVideo = 1;

useGPU = 0;


results = zeros(size(videos,2),size(masks,2),5);

timeElapsed = zeros(1,5);



for i_n = 1:nExperiment
    for i_video = 1:size(videos,2);
        
        load(videos{i_video});        
        video = double(X);
        %SL3D1
        if testSL3D1
            scales1 = 3;
            shearLevels1 = [0, 0, 1];        
        end

        %SL3D2
        if testSL3D2
            scales2 = 3;
            shearLevels2 = [1, 1, 2];       
        end

        %SURF
        if testSURF
            Pyr_mode = 1;
            Lev_array = {[-1 3 3; 3 -1 3; 3 3 -1],[-1 3 3; 3 -1 3; 3 3 -1],[-1 2 2; 2 -1 2; 2 2 -1],[-1 1 1; 1 -1 1; 1 1 -1]};
            bo = 8;
            if exist('surfscalars.mat', 'file')
                load surfscalars.mat;
            else
                surfscalars = SLPaperGetRMS3D(size(video,1),size(video,2),size(video,3),'SURF',Pyr_mode,Lev_array,bo);
                save surfscalars surfscalars;
            end
        end


        %SL2D2
        if testSL2D2
            sl2d2 = SLgetShearletSystem2D(useGPU,sizeX,sizeY,4,[1 1 2 2]);
        end

        %FCT3D
        if testFCT3D
            parameters = curvelet3d_params(video);
        end

        for i_mask = 1:size(masks,2)
            load(masks{i_mask});
            
            mask = double(mask > 254);
            
            videoMasked = video.*mask;
            
            %SL3D1
            if testSL3D1
                tic;
                videoInpainted = real(SLPaperInpaint3D(videoMasked,mask,iterations,stopFactor,'SL3D1',useGPU,scales1,shearLevels1));
                if useGPU
                    wait(g);
                end;
                timeElapsed(1) = toc;
                if saveVideo
                    save results/sl3d1 videoInpainted;
                end;
                results(i_video,i_mask,1) = results(i_video,i_mask,1) + SLcomputePSNR(videoInpainted,video);
            end
            disp('SL3D1');
                        
            %SL3D2
            if testSL3D2
                tic;
                videoInpainted = real(SLPaperInpaint3D(videoMasked,mask,iterations,stopFactor,'SL3D2',useGPU,scales2,shearLevels2));
                if useGPU
                    wait(g);
                end;
                timeElapsed(2) = toc;
                if saveVideo
                    save results/sl3d2 videoInpainted;
                end;
                results(i_video,i_mask,2) = results(i_video,i_mask,2) + SLcomputePSNR(videoInpainted,video);
            end
            disp('SL3D2');
        
            
            %SURF
            if testSURF
                tic;
                videoInpainted = real(SLPaperInpaint3D(videoMasked,mask,iterations,stopFactor,'SURF',Pyr_mode,Lev_array,bo,surfscalars));                
                timeElapsed(3) = toc;
                if saveVideo
                    save results/surf videoInpainted;
                end;
                results(i_video,i_mask,3) = results(i_video,i_mask,3) + SLcomputePSNR(videoInpainted,video);
            end
            disp('SURF');            
           
            %SL2D2
            if testSL2D2
                tic;
                videoInpainted = real(SLPaperInpaint3D(videoMasked,mask,iterations,stopFactor,'SL2D2',sl2d2));
                if useGPU
                    wait(g);
                end;
                timeElapsed(4) = toc;
                if saveVideo
                    save results/sl2d2 videoInpainted;
                end;
                results(i_video,i_mask,4) = results(i_video,i_mask,4) + SLcomputePSNR(videoInpainted,video);
            end
            disp('SL2D2');
             %FCT3D
            if testFCT3D
                tic;
                videoInpainted = real(SLPaperInpaint3D(videoMasked,mask,iterations,stopFactor,'FCT3D',parameters));
                if useGPU
                    wait(g);
                end;
                timeElapsed(5) = toc;
                if saveVideo
                    if i_video == 1 && i_mask == 1                        
                        save results/fct2d videoInpainted;
                    end
                end;
                results(i_video,i_mask,5) = results(i_video,i_mask,5) + SLcomputePSNR(videoInpainted,video);
            end
            disp('FCT3D');
        end
    end
end

disp(results);
if savePSNR
    save results_inpainting_3d_neu results;
    save results_inpainting_3d_time_neu timeElapsed;
end;

if saveVideo
    save results/video video;
    save results/videoMaske videoMasked;
end;